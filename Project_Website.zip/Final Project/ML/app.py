

from flask import Flask, request, jsonify
from naive import predict_sentiment
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/')
def index():
    return "Hello, this is the backend!"

@app.route('/api/predict_sentiment', methods=['POST'])
def predict_sentiment_naive_api():
    data = request.get_json()
    user_review = data.get('review', '')
    
    if not user_review:
        return jsonify({'error': 'Review is required'}), 400

    sentiment, accuracy = predict_sentiment(user_review)
    return jsonify({'sentiment': sentiment, 'accuracy': accuracy})

@app.route('/api/predict_sentiment_neural', methods=['POST'])
def predict_sentiment_neural_api():
    data = request.get_json()
    user_review = data.get('review', '')
    
    if not user_review:
        return jsonify({'error': 'Review is required'}), 400

    # Assuming you have a function predict_sentiment_neural in your neural_network.py
    sentiment, accuracy = predict_sentiment(user_review)
    return jsonify({'sentiment': sentiment, 'accuracy': accuracy})

@app.route('/api/predict_sentiment_decision', methods=['POST'])
def predict_sentiment_naive_api():
    data = request.get_json()
    user_review = data.get('review', '')
    
    if not user_review:
        return jsonify({'error': 'Review is required'}), 400

    sentiment, accuracy = predict_sentiment(user_review)
    return jsonify({'sentiment': sentiment, 'accuracy': accuracy})

@app.route('/api/predict_sentiment_svm', methods=['POST'])
def predict_sentiment_neural_api():
    data = request.get_json()
    user_review = data.get('review', '')
    
    if not user_review:
        return jsonify({'error': 'Review is required'}), 400
    

@app.route('/api/predict_sentiment_xgb', methods=['POST'])
def predict_sentiment_neural_api():
    data = request.get_json()
    user_review = data.get('review', '')
    
    if not user_review:
        return jsonify({'error': 'Review is required'}), 400

    # Assuming you have a function predict_sentiment_neural in your neural_network.py
    sentiment, accuracy = predict_sentiment(user_review)
    return jsonify({'sentiment': sentiment, 'accuracy': accuracy})

if __name__ == '__main__':
    app.run(debug=True)
