
// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Navbar from './components/Navbar.js';
import Home from './components/Home.js';
import About from './components/About';
import DecisionTree from './components/DecisionTree.js';
import NeuralNetworks from './components/NeuralNetworks.js';
import SVM from './components/SVM.js';
import XgBoost from './components/XgBoost.js';
import NaiveBayes from './components/NaiveBayes.js'; // Updated component name
import FinalResults from './components/PieChart.js';

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <div className="content">
          <Switch>                 
            <Route path="/" exact component={Home} />
            <Route path="/about" component={About} />
            <Route path="/nb" exact component={NaiveBayes} />
            <Route path="/dt" exact component={DecisionTree} />
            <Route path="/nn" exact component={NeuralNetworks} />
            <Route path="/svm" exact component={SVM} />
            <Route path="/xg" exact component={XgBoost} />            
            <Route path="/fr" exact component={FinalResults} />
          </Switch>
        </div>
      </div>
    </Router>
  );
}

export default App;
