// NaiveBayesGraph.js
import React, { useState, useEffect } from 'react';
import Chart from 'chart.js/auto';
import './NaiveByesGraph.css'; 

const NaiveBayesGraph = () => {
  const [chart, setChart] = useState(null);

  useEffect(() => {
    const ctx = document.getElementById('naiveBayesChart');
    const newChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['PositiveReviews', 'NegativeReviews'], // Replace with your actual categories
        datasets: [{
          label: 'Naive Bayes Predictions',
          data: [50, 30, 20], // Replace with your actual prediction values
          backgroundColor: [
            'rgba(255, 99, 132, 0.5)',
            'rgba(54, 162, 235, 0.5)',
            'rgba(255, 206, 86, 0.5)',
          ],
          borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
          ],
          borderWidth: 1,
        }],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    // Save the chart instance to the state
    setChart(newChart);

    // Clean up on component unmount
    return () => {
      if (newChart) {
        newChart.destroy();
      }
    };
  }, []); // Empty dependency array ensures the effect runs only once

  return (
    <div className="chart-container">
      <h2>NaiveBayes Graph</h2>
      {/* Set smaller dimensions for the canvas */}
     <center><canvas id="naiveBayesChart" width="200" height="100"></canvas></center> 
    </div>
  );
};

export default NaiveBayesGraph;
