
import React from 'react';
import mvlogo from './fr.jpeg';

const ImageComponent = () => {  

  return (    
    <div style={{ backgroundColor: '#e8e4e1', backgroundSize: 'cover', minHeight: '100vh', padding: '20px' }}>      

      <center><img className="animated-image" src={mvlogo} alt="Logo" style={{ height: '80%',width: '80%', marginRight: '5px' }} /></center><br></br>
    </div>
  );
};

export default ImageComponent;
