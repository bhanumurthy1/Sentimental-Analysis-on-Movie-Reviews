// Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';
import mvlogo from './wb.jpeg';
import './Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="logo">
          <Link to="/">
            <img src={mvlogo} alt="Logo" />
          </Link>
        </div>
        <ul className="nav-links">
          <li><Link to="/nb">NaiveBayes</Link></li>
          <li><Link to="/dt">Decision Tree</Link></li>
          <li><Link to="/svm">SVM</Link></li>
          <li><Link to="/nn">Neural Networks</Link></li>
          <li><Link to="/xg">XgBoost</Link></li>
          <li><Link to="/fr">Final Results</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/">Home</Link></li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;