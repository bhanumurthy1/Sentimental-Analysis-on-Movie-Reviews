// Home.js
import React, { useState } from 'react';

const Home = () => {
  const [isHovered, setIsHovered] = useState(false);

  const containerStyle = {
    textAlign: 'center',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    maxWidth: '600px',
    margin: '50px auto',
    position: 'relative',
    color: '#fff',
  };

  const headingStyle = {
    fontSize: '2.3em',
    marginBottom: '10px',
    color: '#d65e4b',
  };

  const paragraphStyle = {
    fontSize: '1.5em',
    marginBottom: '20px',
    color: '#fff'
  };

  const buttonStyle = {
    backgroundColor: '#fff',
    color: '#3498db',
    padding: '10px 20px',
    borderRadius: '5px',
    border: 'none',
    cursor: 'pointer',
    fontSize: '1em',
    fontWeight: 'bold',
    transition: 'background-color 0.3s',
  };

  const buttonHoverStyle = {
    backgroundColor: '#ecf0f1',
  };

  return (
    <div style={containerStyle}>
      <h1 style={headingStyle}>Welcome to the Movie Review System</h1>
      <p style={paragraphStyle}>Explore and discover the latest movies. Read and write reviews to share your thoughts with the community.</p>
      
      <h2 style={headingStyle}>Featured Movies</h2>
      {/* Display a list of featured movies or movie posters here */}

      <a href="https://www.imdb.com/" target="_blank" rel="noopener noreferrer">
        <button 
          style={{ ...buttonStyle, ...(isHovered && buttonHoverStyle) }} 
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          Explore IMDb
        </button>
      </a>
    </div>
  );
};

export default Home;