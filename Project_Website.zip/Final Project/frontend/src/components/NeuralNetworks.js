
// NeuralNetworks.js
import React, { useState } from 'react';
import mvlogo from '../nn.jpeg';

const NeuralNetworks = () => {
  const [userInput, setUserInput] = useState('');
  const [predictionResult, setPredictionResult] = useState('');

  const predict = async () => {
    try {
      
        const response = await fetch('http://localhost:5000/api/predict_sentiment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ review: userInput }),
      });

      const result = await response.json();
      setPredictionResult(result.sentiment);
    } catch (error) {
      console.error('Error predicting sentiment:', error);
    }
  };

  return (
    <div style={{ backgroundColor: '#e8e4e1', backgroundSize: 'cover', minHeight: '100vh', padding: '20px' }}>
      <br></br>
     
      <center><img  className="animated-image" src={mvlogo} alt="Logo" style={{ height: '170px',width: '280px', marginRight: '5px' }} /></center><br></br>
      <center><label htmlFor="userInput"><bold>Enter Text:</bold></label> <br></br> <br></br></center>
      <center><textarea
        className="custom-textarea"
        placeholder="Type Movie Review here..."
        id="userInput"
        name="userInput"
        rows="4"
        cols="50"
        value={userInput}
        onChange={(e) => setUserInput(e.target.value)}
      ></textarea></center>
      <br />

      <center><button onClick={predict}>Predict</button></center>

      <div>
        <center>
          <h3>Output:</h3>
        </center>
        <center><div style={{ fontWeight:'bold', color: 'orange', fontFamily: 'Courier', fontSize: '2em' }}>{predictionResult}</div></center>
      </div>
    </div>
  );
};

export default NeuralNetworks;
