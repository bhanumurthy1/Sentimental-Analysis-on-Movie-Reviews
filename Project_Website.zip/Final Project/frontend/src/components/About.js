// Home.js
import React from 'react';
import VideoComponent from './VideoComponent';

const About = () => {
  return (
    <div>
      <center><VideoComponent /></center>
    </div>
  );
};

export default About;
