// Home.js
import React from 'react';
import AccuracyChart from './PieChart';

const FinalResults = () => {
  return (
    
    <div>
      <AccuracyChart/>
    </div>
  );
};

export default FinalResults;
